var click=1;
var rclick=1;
function addItems(){
  var name= document.getElementById("name").value;
  var origin= document.getElementById("origin").value;
  var dest= document.getElementById("dest").value;
  var price= document.getElementById("price").value;
  var rate= document.getElementById("rating").value;
  if(name==""|origin==""|dest==""|price==""|rate==""){
    document.querySelector('.errorcl').style.display="block";
  }
  else{
   var flight = new Object();
    flight.name= name;
    flight.origin = origin;
    flight.destination =dest;
    flight.price = price;
    flight.rating = rate;
    flightItems.push(flight);
    document.getElementById("name").value="";
    document.getElementById("origin").value = "";
    document.getElementById("dest").value="";
    document.getElementById("price").value="";
    document.getElementById("rating").value="";
    
   //flightItems.forEach(display);
    }
}

function display(flights)
{
  
   var div = document.getElementById("container");
    var ul = document.createElement("ul");
    ul.className="card";
    var li1 = document.createElement("li");
    var li2 = document.createElement("li");
    var li3 = document.createElement("li");
    var li4 = document.createElement("li");
    li1.appendChild(document.createTextNode("Flight Name: "+flights.name));
    li2.appendChild(document.createTextNode(flights.origin+" to "+flights.destination));
    li3.appendChild(document.createTextNode("Rating : "+flights.rating));
    li4.appendChild(document.createTextNode("Price: Rs."+flights.price));
    ul.appendChild(li1);
    ul.appendChild(li2);
    ul.appendChild(li3);
    ul.appendChild(li4);
    div.appendChild(ul);  
  
  setTimeout(clearlist,1000);
}

function sortByPrice(){
    var span = document.getElementById("sprice");
 if(click%2!=0){ 
   span.textContent="Sort By Price asc"
  flightItems.sort((a, b) => parseFloat(a.price) - parseFloat(b.price)); 
   } 
  
 if(click%2==0){ 
    span.textContent="Sort By Price desc"
   flightItems.sort((a, b) => parseFloat(b.price) - parseFloat(a.price));
}
   click=click+1;
  
  flightItems.forEach(display);
  
}

function sortByRating(){
    var span = document.getElementById("srate");
 if(rclick%2!=0){ 
   span.textContent="Sort By Rating asc"
  flightItems.sort((a, b) => parseFloat(a.rating) - parseFloat(b.rating)); 
   } 
  
 if(rclick%2==0){ 
    span.textContent="Sort By Rating desc"
   flightItems.sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
}
  
   rclick=rclick+1;
  //clear
  flightItems.forEach(display);
}


function clearlist (){ 
	document.querySelectorAll('.card').forEach(function(a) {
  a.remove()
})
	} 